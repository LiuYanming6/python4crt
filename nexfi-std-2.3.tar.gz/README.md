# nexfi-std
Nexfi-std for mobile mesh net intercommunication.
